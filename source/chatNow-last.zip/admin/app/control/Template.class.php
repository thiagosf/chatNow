<?php

class Template
{
	
	public static function getHeader() {
		require('view/header.php');
	}
	
	public static function getFooter() {
		require('view/footer.php');
	}
	
}

?>