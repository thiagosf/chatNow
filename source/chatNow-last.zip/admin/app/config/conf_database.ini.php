<?php

// Local
$conf[0]['server'] 		= 'localhost';
$conf[0]['user'] 		= 'root';
$conf[0]['password'] 	= '123';
$conf[0]['database'] 	= 'chat';

// Web
$conf[1]['server'] 		= '';
$conf[1]['user'] 		= '';
$conf[1]['password'] 	= '';
$conf[1]['database'] 	= '';

?>