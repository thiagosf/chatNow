<?php

/**
 * Configuração do banco
 */
define('ID_CONFIG_DB', 						(stristr($_SERVER['HTTP_HOST'], 'local')) ? 0 : 1 );

?>