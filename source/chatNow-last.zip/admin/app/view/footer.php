	
	<div id="footer">
		<p>Administration - <?php echo date('Y'); ?></p>
	</div>

</body>
</html>
